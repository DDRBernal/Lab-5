/**
 * 
 */
/**
 * @author davidandres
 *
 */
module Kalah {
	exports presentacion;
	exports aplicacion;

	requires java.desktop;
	requires javafx.graphics;
}