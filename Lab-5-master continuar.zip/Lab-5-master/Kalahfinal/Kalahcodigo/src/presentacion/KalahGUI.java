package presentacion;
import aplicacion.KalahGame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;
//import javax.xml.soap.Text;

/**
 * @version ECI 2019
 */
public class KalahGUI extends JFrame {
    static JFrame frame;
    private JMenuBar menuBar;
    private JMenu menu,reiniciar;
    private JMenu opciones,cantidadSemillas,cantidadCeldas;
    private JMenuItem nuevo,abrir,salvar,salvarComo,salir,chooseColorUsuario,chooseColorMaquina;
    private JLabel titulo;
    private ImageIcon tituloP;
    private JPanel panel1;
    private JPanel board,board2,board3,board4,board5,board6, board7;
    private JLabel jugador,maquina,jugadas;
    private int[] matrizSemillas;
    private int[] matrizSolucion;
    private Color colorEscogido,colorEscogido2;
    private boolean colorCambiado= false;
    private boolean colorCambiado2= false;
    private int tamano= 6;
    private int Semillas= 3;
    private int semillasUsuario=0;
    private int semillasMaquina=0;
    private KalahGame game;
    private int conta=0;
    private JTextField numIngreUsuario,numIngreMauina;
    private ArrayList<JButton> buttonGrid= new ArrayList<JButton>();
    private JButton aceptar;
    private JButton accept;
    private int numeroJugadas=0;
    
    
    private KalahGUI(){
        super("Kalah");
        colorEscogido= new Color(111, 181, 253);
        game = new KalahGame(tamano,6);
        prepareElementos();
        prepareElementosMenu();
        prepararElementosTablero();
        prepareAcciones();
    }

    private void key(KeyEvent e) {
        int id= e.getKeyCode();

        if(id== KeyEvent.VK_RIGHT) {
            game.moveRight();
            limpiar();

        }
        else if(id == KeyEvent.VK_LEFT) {
            game.moveLeft();
            limpiar();
        }
        else if(id == KeyEvent.VK_DOWN) {
            game.moveDown();
            limpiar();
        }
        else if(id == KeyEvent.VK_UP) {
            game.moveUp();
            limpiar();
        }
    }

    private void prepareElementosMenu(){
        menuBar= new JMenuBar();
        menu= new JMenu("Menu");
        reiniciar= new JMenu("Reiniciar");
        abrir= new JMenuItem("Abrir");
        menu.add(abrir);
        salvar= new JMenuItem("Salvar");
        menu.add(salvar);
        salvarComo= new JMenuItem("Salvar como");
        menu.add(salvarComo);
        salir= new JMenuItem("Salir");
        menu.add(salir);
        opciones= new JMenu("Opciones");
        chooseColorUsuario= new JMenuItem("Escoge color usuario");
        chooseColorMaquina= new JMenuItem("Escoge color Maquina");
        opciones.add(chooseColorUsuario);
        opciones.add(chooseColorMaquina);
        cantidadSemillas= new JMenu("Elija cantidad de Semillas");
        opciones.add(cantidadSemillas);
        cantidadCeldas= new JMenu("Elija tamaño del tablero");
        opciones.add(cantidadCeldas);
        aceptar  = new JButton("Aceptar");
        accept  = new JButton("Aceptar");
        numIngreUsuario = new JTextField(); 
        numIngreUsuario.setBounds(120,18,90,30);
        numIngreMauina=new JTextField();
        numIngreMauina.setBounds(120,18,90,30);
        menuBar.add(menu);
        menuBar.add(opciones);
        menuBar.add(reiniciar);
        cantidadCeldas.add(numIngreUsuario);
        cantidadCeldas.add(aceptar);
        cantidadSemillas.add(numIngreMauina);
        cantidadSemillas.add(accept);
        this.setJMenuBar(menuBar);
    }

    private void prepararPosicionSemillas() {
        matrizSemillas= game.getSemillas();
        matrizSolucion= game.getSolucion();

    }
    private void prepararElementosTablero() {
        prepareTitulo();
        prepareGrid(tamano);
    }

    private void prepareTitulo() {
        setLayout(new BorderLayout());
        panel1= new JPanel();
        tituloP= new ImageIcon("Recursos/tittle.png");
        titulo= new JLabel(tituloP);
        panel1.add(titulo);
        this.add(panel1,BorderLayout.NORTH);
    }



    private void prepareGrid(int tamano) {
        board= new JPanel();
        board.setLayout(new GridLayout(tamano,tamano,5,5));
        board.setBackground(Color.DARK_GRAY);
        board.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY,4));
        prepararPosicionSemillas();
        for(int i= 0; i < tamano*2; i++) {
                if (i%2==0){
                    if(!colorCambiado) {colorEscogido=Color.GREEN;}
                    prepareSemillas(i,colorEscogido);

                }
                else{
                    if(!colorCambiado2) {colorEscogido2=new Color(111, 181, 253);}
                    prepareSemillas(i,colorEscogido2);
                }
        }

        for (int i=0; i<buttonGrid.size(); i++){
            final int a=i;
            buttonGrid.get(i).addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    System.out.println(a);
                    buttonGrid.get(a).setText("sdsdsdsd");
                }
            });
        }

        board2= new JPanel();
        board2.setLayout(new GridLayout(3,tamano,1,1));
        board2.setBackground(colorEscogido);
        board2.setBorder(BorderFactory.createLineBorder(new Color(111, 181, 253),4));


        board3= new JPanel();
        board3.setBackground(colorEscogido2);
        board3.setLayout(new GridLayout(3,tamano,1,1));
        board3.setBorder(BorderFactory.createLineBorder(new Color(129, 140, 235),4));

        
        jugador = new JLabel("Cantidad semillas Jugador: "+Integer.toString(semillasUsuario),SwingConstants.CENTER);
        jugador.setBackground(colorEscogido);
        board2.add(jugador);
        
        
        maquina = new JLabel("Cantidad semillas PC: "+Integer.toString(semillasMaquina),SwingConstants.CENTER);
        maquina.setBackground(colorEscogido2);
        board3.add(maquina);
        
        jugadas=new JLabel("Numero jugadas: "+Integer.toString(numeroJugadas));
        jugadas.setBackground(colorEscogido2);		
        board3.add(jugadas);		
        		
        board5= new JPanel();
        board5.setLayout(new GridLayout(1,tamano,1,1));
        maquina = new JLabel("maquina");
        board5.add(maquina);

        board6= new JPanel();
        board6.setLayout(new GridLayout(1,tamano,1,1));
        jugador = new JLabel("jugador");
        board6.add(jugador);

        this.add(board, BorderLayout.CENTER);
        this.add(board2, BorderLayout.SOUTH);
        this.add(board5, BorderLayout.EAST);
        this.add(board6, BorderLayout.WEST);
        this.add(board3, BorderLayout.NORTH);
        this.revalidate();
        this.repaint();

    }

    private void prepareSemillas(int i,Color color) {
        JButton myButton = new JButton(Integer.toString(Semillas));
        buttonGrid.add(myButton);
//        System.out.println(i+" "+j);
        if (i==0) {
            System.out.println(color);
            System.out.println(i);
            myButton.setBackground(color);
            myButton.setOpaque(true);
            board.add(myButton);
            conta+=1;
        } 
        else{
            myButton.setBackground(color);
            myButton.setOpaque(true);
            board.add(myButton);
            conta=0;
        }
    }

    private void abrirArchivo() {
        JFileChooser file = new JFileChooser();
        file.setDialogTitle("archivos a elegir");
        file.setFileSelectionMode(JFileChooser.FILES_ONLY);
        if (file.showOpenDialog(abrir) == JFileChooser.APPROVE_OPTION) {
            JOptionPane.showMessageDialog(null, "La funcion abrir esta en construccion ");
        }
    }

    private void prepareElementos() {
        this.setTitle("Kalah");
        Dimension screen = tamanoPantalla();
        this.setSize(new Dimension(screen.width/2,screen.height/2));
        centre();
    }

    private void prepareAcciones(){
        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE );
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                salir();
            }
        });
        abrir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abrirArchivo();
            }
        });
        salvar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                salvarArchivo();
            }
        });
        salir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                salir();
            }
        });
        chooseColorUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                chooseColor();
            }
        });
        chooseColorMaquina.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                chooseColor2();
            }
        });
        aceptar.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				nuevo();
			}
		});
        accept.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				nuevo2();
			}
		});
        reiniciar.addMouseListener(new MouseAdapter(){
			
			public  void mouseClicked(MouseEvent e){
				reStart() ;
			}

		});
        addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent e) {
                key(e);
            }

            @Override
            public void keyReleased(KeyEvent e) {
                // TODO Auto-generated method stub
            }

            @Override
            public void keyPressed(KeyEvent e) {
                key(e);
            }
        });
    }

    private void chooseColor() {
        colorCambiado=true;
        colorEscogido= JColorChooser.showDialog(null, "color usuario", colorEscogido);
        if (colorEscogido == null) {
            colorEscogido= Color.GREEN;
        }
        refresque();
    }

    private void chooseColor2() {
        colorCambiado2=true;
        colorEscogido2= JColorChooser.showDialog(null, "color maquina", colorEscogido2);
        if (colorEscogido == null) {
            colorEscogido2= Color.BLUE;
        }
        refresque();
    }

    private void limpiar() {
        board.removeAll();
        panel1.removeAll();
        this.remove(panel1);
        this.remove(board);
        prepararElementosTablero();
        refresque();
    }

    private void reStart() {
    	tamano= 6;
        Semillas= 3;
        semillasUsuario=0;
        semillasMaquina=0;
        numeroJugadas=0;
        colorCambiado= false;
        colorCambiado2= false;
        refresque();
    }
    private void refresque() {
        board.removeAll();
        board2.removeAll();
        board3.removeAll();
        this.remove(board);
        this.remove(board2);
        this.remove(board3);
        prepareGrid(tamano);
        this.revalidate();
        repaint();
    }

    private void salvarArchivo() {
        JFileChooser file= new JFileChooser();
        file.setSelectedFile(new File("save.txt"));
        file.showSaveDialog(salvar);
        try{
            String link  =  file.getSelectedFile().getName();
            String files = link.replaceAll("[^a-zA-Z0-9.]"," ");
            String[] split = files.split(" ");
            JOptionPane.showMessageDialog(null, "La funcion guardar esta en construccion ");
        }catch(Exception e){}
    }

    private void salir(){
        int dialogButton = JOptionPane.showConfirmDialog (null, "Are you sure??","WARNING",JOptionPane.YES_NO_OPTION);
        if(dialogButton == JOptionPane.YES_OPTION) {
            System.exit(0);}else {remove(dialogButton);}
    }

    private void centre(){
        Dimension screen= tamanoPantalla();
        int xEsquina = (screen.width - getSize().width )/2;
        int yEsquina = (screen.height - getSize().height )/2;
        this.setLocation(xEsquina,yEsquina);
    }

    private Dimension tamanoPantalla(){
        return Toolkit.getDefaultToolkit().getScreenSize();
    }
    
    private void nuevo(){
		int solicitadoH = Integer.parseInt(numIngreUsuario.getText());
		if(solicitadoH>1){
			tamano = solicitadoH;
			refresque();
		}
		else{
			JOptionPane.showMessageDialog(null,"cambie el numero de canicas");
		}
	}
    
    private void nuevo2(){
		int solicitadoH = Integer.parseInt(numIngreMauina.getText());
		if(solicitadoH>1){
			System.out.println("entro");
			Semillas = solicitadoH;
			refresque();

		}
		else{
			JOptionPane.showMessageDialog(null,"cambie el numero de canicas");
		}
	}

    public static void main(String[] args){
        KalahGUI kalah = new KalahGUI();
        kalah.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        kalah.setVisible(true);
    }

}